namespace Project.Scripts
{
    public interface ITakeDamage
    {
        void TakeDamage(int damage);
    }
}
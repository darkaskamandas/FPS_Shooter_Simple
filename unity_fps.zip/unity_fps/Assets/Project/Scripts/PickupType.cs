namespace Project.Scripts
{
    public enum PickupType
    {
        Health,
        Ammo
    }
}
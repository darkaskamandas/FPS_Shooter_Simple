namespace Project.Scripts
{
    public interface IWeaponAmmo
    {
        int CurrentAmmo { get; }
        int MaxAmmo { get; }
    }
}
